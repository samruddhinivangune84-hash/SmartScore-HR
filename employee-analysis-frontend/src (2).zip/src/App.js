import { Routes, Route } from "react-router-dom";
import AdminDashboard from "./Pages/AdminDashboard";
import ManagerDashboard from "./Pages/ManagerDashboard";
import EmployeeDashboard from "./Pages/EmployeeDashboard";
import Tasks from "./Pages/Tasks";
import Employees from "./Pages/Employees";
import Reports from "./Pages/Reports";
import Login from "./Pages/Login";
import Register from "./Pages/Register";   // ✅ ADD THIS

function App() {
  return (
    <Routes>
      <Route path="/" element={<Login />} />
      <Route path="/login" element={<Login />} />   {/* optional but recommended */}
      <Route path="/register" element={<Register />} />   {/* ✅ ADD THIS */}

      <Route path="/admin-dashboard" element={<AdminDashboard />} />
      <Route path="/manager-dashboard" element={<ManagerDashboard />} />
      <Route path="/employee-dashboard" element={<EmployeeDashboard />} />

      <Route path="/tasks" element={<Tasks />} />
      <Route path="/employees" element={<Employees />} />
      <Route path="/reports" element={<Reports />} />
    </Routes>
  );
}

export default App;