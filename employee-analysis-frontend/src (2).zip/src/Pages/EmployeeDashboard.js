import React, { useState, useEffect } from "react";
import DashboardLayout from "../layout/DashboardLayout";
import {
  getEmployeeTasks,
  completeTask,
  getLeaves,
  applyLeave,
  getProductivityScore
} from "../api";

function EmployeeDashboard({ user }) {

  const [tasks, setTasks] = useState([]);
  const [leaves, setLeaves] = useState([]);
  const [score, setScore] = useState(0);

  const [leaveForm, setLeaveForm] = useState({
    startDate: "",
    endDate: "",
    reason: ""
  });

  // ==============================
  // Load dashboard data
  // ==============================

  useEffect(() => {

    if (!user?.email) return;

    fetchTasks();
    fetchLeaves();
    fetchProductivity();

  }, [user]);

  // ==============================
  // Fetch Tasks
  // ==============================

  const fetchTasks = async () => {

    try {

      const res = await getEmployeeTasks(user.email);

      if (res?.data) {
        setTasks(res.data);
      }

    } catch (err) {

      console.error("Error loading tasks:", err);

    }

  };

  // ==============================
  // Fetch Leaves
  // ==============================

  const fetchLeaves = async () => {

    try {

      const res = await getLeaves(user.email);

      if (res?.data) {
        setLeaves(res.data);
      }

    } catch (err) {

      console.error("Error loading leaves:", err);

    }

  };

  // ==============================
  // Fetch Productivity Score
  // ==============================

  const fetchProductivity = async () => {

    try {

      const res = await getProductivityScore(user.email);

      if (res?.data !== undefined) {
        setScore(res.data);
      }

    } catch (err) {

      console.error("Error loading productivity score:", err);

    }

  };

  // ==============================
  // Leave Form Handling
  // ==============================

  const handleLeaveChange = (e) => {

    const { name, value } = e.target;

    setLeaveForm(prev => ({
      ...prev,
      [name]: value
    }));

  };

  const submitLeave = async (e) => {

    e.preventDefault();

    try {

      await applyLeave({
        ...leaveForm,
        employeeEmail: user.email
      });

      alert("Leave submitted successfully");

      setLeaveForm({
        startDate: "",
        endDate: "",
        reason: ""
      });

      fetchLeaves();

    } catch (err) {

      console.error("Leave submission error:", err);
      alert("Failed to submit leave");

    }

  };

  // ==============================
  // Complete Task with File Upload
  // ==============================

  const handleCompleteTask = async (taskId, file) => {

    if (!file) {
      alert("Please select a file");
      return;
    }

    try {

      await completeTask(taskId, file);

      alert("Task submitted successfully");

      fetchTasks();
      fetchProductivity();

    } catch (err) {

      console.error("Task completion error:", err);
      alert("Failed to upload file");

    }

  };

  // ==============================
  // UI
  // ==============================

  return (

    <DashboardLayout>

      {/* Productivity Card */}

      <div className="card">

        <h3>AI Productivity Score</h3>

        <h1>{score}%</h1>

        {score >= 80 && <p>Excellent Performance</p>}
        {score >= 60 && score < 80 && <p>Good Performance</p>}
        {score < 60 && <p>Needs Improvement</p>}

      </div>


      {/* ================= TASKS ================= */}

      <div className="card">

        <h3>Your Tasks</h3>

        <table>

          <thead>

            <tr>
              <th>Title</th>
              <th>Description</th>
              <th>Deadline</th>
              <th>Status</th>
              <th>Upload Completion</th>
            </tr>

          </thead>

          <tbody>

            {tasks.length === 0 ? (

              <tr>
                <td colSpan="5">No tasks assigned</td>
              </tr>

            ) : (

              tasks.map((task) => (

                <tr key={task.id}>

                  <td>{task.title}</td>
                  <td>{task.description}</td>
                  <td>{task.deadline}</td>
                  <td>{task.status}</td>

                  <td>

                    {task.status !== "Completed" ? (

                      <input
                        type="file"
                        onChange={(e) =>
                          handleCompleteTask(task.id, e.target.files[0])
                        }
                      />

                    ) : (

                      <span>Submitted</span>

                    )}

                  </td>

                </tr>

              ))

            )}

          </tbody>

        </table>

      </div>


      {/* ================= LEAVE ================= */}

      <div className="card">

        <h3>Apply for Leave</h3>

        <form onSubmit={submitLeave}>

          <label>Start Date</label>

          <input
            type="date"
            name="startDate"
            value={leaveForm.startDate}
            onChange={handleLeaveChange}
            required
          />

          <label>End Date</label>

          <input
            type="date"
            name="endDate"
            value={leaveForm.endDate}
            onChange={handleLeaveChange}
            required
          />

          <label>Reason</label>

          <textarea
            name="reason"
            value={leaveForm.reason}
            onChange={handleLeaveChange}
            required
          />

          <button type="submit">
            Submit Leave
          </button>

        </form>


        <h3>Your Leaves</h3>

        <table>

          <thead>

            <tr>
              <th>Start Date</th>
              <th>End Date</th>
              <th>Reason</th>
              <th>Status</th>
            </tr>

          </thead>

          <tbody>

            {leaves.length === 0 ? (

              <tr>
                <td colSpan="4">No leaves applied</td>
              </tr>

            ) : (

              leaves.map((leave) => (

                <tr key={leave.id}>

                  <td>{leave.startDate}</td>
                  <td>{leave.endDate}</td>
                  <td>{leave.reason}</td>
                  <td>{leave.status}</td>

                </tr>

              ))

            )}

          </tbody>

        </table>

      </div>

    </DashboardLayout>

  );

}

export default EmployeeDashboard;