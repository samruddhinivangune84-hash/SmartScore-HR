import React from "react";
import { Link, useLocation } from "react-router-dom";
import "./DashboardLayout.css";

function DashboardLayout({ children }) {

  const location = useLocation();

  const menu = [
    { name: "Dashboard", path: "/admin-dashboard" },
    { name: "Managers", path: "/admin-dashboard#managers" },
    { name: "Employees", path: "/admin-dashboard#employees" },
    { name: "Tasks", path: "/admin-dashboard#tasks" }
  ];

  return (
    <div className="layout">

      {/* SIDEBAR */}

      <div className="sidebar">

        <div className="logo">
          Admin Panel
        </div>

        <nav className="menu">

          {menu.map((item) => (
            <Link
              key={item.name}
              to={item.path}
              className={`menu-item ${
                location.pathname === item.path ? "active" : ""
              }`}
            >
              {item.name}
            </Link>
          ))}

        </nav>

      </div>

      {/* MAIN AREA */}

      <div className="main">

        <div className="topbar">
          <h2>Admin Dashboard</h2>

          <button
            className="logout-btn"
            onClick={() => {
              localStorage.clear();
              window.location.href = "/";
            }}
          >
            Logout
          </button>
        </div>

        <div className="content">
          {children}
        </div>

      </div>

    </div>
  );
}

export default DashboardLayout;