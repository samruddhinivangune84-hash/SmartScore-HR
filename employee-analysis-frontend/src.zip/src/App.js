import axios from "axios";

// Create Axios instance
const api = axios.create({
  baseURL: "http://localhost:8080/api", // Your Spring Boot API base URL
  headers: {
    "Content-Type": "application/json",
  },
  timeout: 5000, // optional timeout
});

// Optional: interceptors for logging or error handling
api.interceptors.response.use(
  (response) => response,
  (error) => {
    console.error("API Error:", error);
    return Promise.reject(error);
  }
);

export default api;