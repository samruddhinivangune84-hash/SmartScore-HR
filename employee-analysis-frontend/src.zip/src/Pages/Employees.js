import React, { useEffect, useState } from "react";
import api from "../services/api";

function Employees() {
  const [employees, setEmployees] = useState([]);

  useEffect(() => {
    api.get("/employees")
      .then(res => setEmployees(res.data))
      .catch(err => console.error(err));
  }, []);

  return (
    <div style={{ marginLeft: "220px", padding: "20px" }}>
      <h2>Employees</h2>
      <pre>{JSON.stringify(employees, null, 2)}</pre>
    </div>
  );
}

export default Employees;