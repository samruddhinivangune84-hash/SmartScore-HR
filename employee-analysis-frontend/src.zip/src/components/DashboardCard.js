import React from "react";
import "../styles/dashboard.css";

function DashboardCard({ title, value }) {
  return (
    <div className="card">
      <h4>{title}</h4>
      <h2>{value}</h2>
    </div>
  );
}

export default DashboardCard;