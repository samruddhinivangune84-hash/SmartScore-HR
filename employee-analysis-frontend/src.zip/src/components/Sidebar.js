import React from "react";
import "../styles/sidebar.css";
import { Link } from "react-router-dom";

function Sidebar() {
  return (
    <div className="sidebar">
      <h2>ProductivityAI</h2>
      <ul>
        <li><Link to="/">Dashboard</Link></li>
        <li><Link to="/employees">Employees</Link></li>
        <li><Link to="/tasks">Tasks</Link></li>
        <li><Link to="/productivity">Productivity</Link></li>
      </ul>
    </div>
  );
}

export default Sidebar;