import React from "react";
import Sidebar from "../components/Sidebar";
import Header from "../components/Header";

function DashboardLayout({ children }) {
  return (
    <div>
      <Sidebar />
      <Header />
      <div>{children}</div>
    </div>
  );
}

export default DashboardLayout;